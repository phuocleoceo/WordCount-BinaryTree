﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace BinaryTree
{
    public class Tree
    {
        public string Word;
        public int Count;
        public Tree Left, Right;
        public Tree()
        {
            Word = "";
            Count = 0;
            Left = Right = null;
        }
    }
    class Program
    {
        static Tree root = null;
        static void LNR(Tree root)
        {
            if (root != null)
            {
                LNR(root.Left);
                Console.WriteLine("{0,10}\t\t{1}", root.Word, root.Count);
                LNR(root.Right);
            }
        }
        static Tree EndLeftNode(Tree root)
        {
            Tree p = root;
            while (p.Left != null) p = p.Left;
            return p;
        }
        static Tree CreateNode(string Word, int Count)
        {
            Tree p = new Tree();
            p.Left = null;
            p.Right = null;
            p.Word = String.Copy(Word);
            p.Count = Count;
            return p;
        }
        static Tree InsertNode(Tree root, string Word, int Count)
        {
            if (root == null) root = CreateNode(Word, Count);
            else if (String.Compare(root.Word, Word, true) >= 0)
            {
                root.Left = InsertNode(root.Left, Word, Count);
            }
            else
            {
                root.Right = InsertNode(root.Right, Word, Count);

            }
            return root;
        }
        static Tree Search(Tree root, string Word)
        {
            if (root == null) return null;
            Tree p = root;
            while (p != null)
            {
                if (String.Compare(p.Word, Word) == 0) return p;
                else if (String.Compare(p.Word, Word) > 0) p = p.Left;
                else p = p.Right;
            }
            return p;
        }
        static int IsAlpha(char c)
        {
            if (c >= 'A' && c <= 'Z') return 1;
            return 0;
        }

        static Tree DeleteNode(Tree root, string Word)
        {
            if (root == null) return root;
            if (String.Compare(root.Word, Word) > 0)
                root.Left = DeleteNode(root.Left, Word);
            else if (String.Compare(root.Word, Word) < 0)
                root.Right = DeleteNode(root.Right, Word);
            else
            {
                if (root.Left == null)
                {
                    Tree p = root.Right;
                    root = null;
                    return p;
                }
                else if (root.Right == null)
                {
                    Tree p = root.Left;
                    root = null;
                    return p;
                }
                else
                {
                    Tree p = EndLeftNode(root.Right);
                    root.Word = String.Copy(p.Word);
                    root.Count = p.Count;
                    root.Right = DeleteNode(root.Right, p.Word);
                }
            }
            return root;
        }
        static void Handling()
        {
            StreamReader reader = new StreamReader("input.txt");
            int Count;
            int k = 0;

            string[] LINES = File.ReadAllText("input.txt").ToUpper().Split(new char[0], StringSplitOptions.RemoveEmptyEntries);
            foreach (string Line in LINES)
            {
                string UniqueWord = "";
                for (int i = 0; i < Line.Length; i++)
                {
                    if (IsAlpha(Line[i]) == 1)
                    {
                        UniqueWord = UniqueWord + Line[i];
                    }
                    if (IsAlpha(Line[i]) == 0 || i == Line.Length - 1)
                    {
                        Tree search = Search(root, UniqueWord);
                        if (search == null)
                        {
                            if (k == 100) break;

                            if (String.Compare(UniqueWord, "") != 0)
                            {
                                k++;
                                root = InsertNode(root, UniqueWord, 1);
                                UniqueWord = "";
                            }
                        }
                        else
                        {
                            Count = search.Count;
                            root = DeleteNode(root, UniqueWord);
                            root = InsertNode(root, UniqueWord, ++Count);
                            UniqueWord = "";
                        }
                    }
                }

            }

        }
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Handling();
            LNR(root);
            Console.ReadKey();
        }

    }
}
