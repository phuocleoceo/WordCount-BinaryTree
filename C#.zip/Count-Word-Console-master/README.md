# Count-Word-Console
Code đồ án Console bằng C# 
file input paste vào thư mục bin / Debug